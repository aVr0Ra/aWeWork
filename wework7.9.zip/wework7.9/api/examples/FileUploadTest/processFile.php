<?php
echo "Excel chart processing... Please Wait..." . "<br />";

//echo "ver = 0.5" . "<br />";

$target_dir = "upload/";
$file = $_FILES['my_file']['name'];
$path = pathinfo($file);
$filename = "MessageSentAt" . date('Y,m,d;H:i:s'); //filename
//var_dump($filename);
$ext = $path['extension']; //.xlsx
//var_dump($ext);
$temp_name = $_FILES['my_file']['tmp_name'];
$path_filename_ext = $target_dir.$filename.".".$ext;
//var_dump($path_filename_ext);

move_uploaded_file($temp_name,$path_filename_ext);

echo "COngratulations! Chart " . $path_filename_ext . " succcessfully saved in server!.....Waiting for the next step..." . "<br /> <br />";


/**************************processing excel chart******************************/
require 'vendor/autoload.php';
require 'Messager.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

$inputFileName = $path_filename_ext;
$spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($inputFileName);

echo "Excel AutoSending Machine Ver 1.4.1" . "<br />";
/*
$test = 'A';
$test2 = '1';
$ans = $test . $test2;
var_dump($ans); echo "<br />";*/

$A1 = $spreadsheet->getActiveSheet()->getCell('A1')->getValue();
var_dump($A1); echo "<br />";

echo $spreadsheet->getActiveSheet()->getCell('A1')->getValue() . "<br />";



$prefixUsername = 'A';
for ($i = 1 ; ; $i ++) {
	$now = $prefixUsername . $i;
	$nowValue = $spreadsheet->getActiveSheet()->getCell($now)->getValue();
	
	if ($nowValue == null) {
		break;
	}
	
	echo $now . " value = " . $nowValue . "<br />";
}


echo "loop fininshed";














?>
