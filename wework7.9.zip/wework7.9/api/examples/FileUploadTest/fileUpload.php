<!DOCTYPE HTML>
<form name = "form" action = "processFile.php" method = "post" enctype="multipart/form-data">

<html>
<body>
	<input type = "file" name = "my_file" accept = ".xls, .xlsx, .csv"/> <br /> <br />
	<input type = "submit" name = "submit" value = "提交该excel表格" />
</body>
</html>

</form>
