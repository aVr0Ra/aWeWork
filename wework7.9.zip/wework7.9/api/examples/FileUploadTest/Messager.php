<?

class Message {
	private $username;
	private $message;

	public function __construct($a, $b) {
		$this->username = $a;
		$this->message = $b;
		return ;
	}
	
	public function sendMessage() {
	}
}

?>
